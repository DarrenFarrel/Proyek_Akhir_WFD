

<?php $__env->startSection('title', 'Hotel Information'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-[#F1EDE6]">
    <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <div class="flex-1 p-8 transition-all duration-300">
        <div class="max-w-4xl mx-auto">
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-[#3A2D28] mb-2 font-serif">Hotel Information</h1>
                <div class="w-20 h-1 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] rounded-full"></div>
            </div>
            
            <div class="bg-[#EBE3DB] p-8 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl">
                <form action="<?php echo e(route('admin.hotel-info.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Hotel Name</label>
                            <input type="text" name="name" value="<?php echo e(old('name', $hotelInfo->name ?? '')); ?>" required
                                   class="w-full p-3 border border-[#A48374] rounded-lg focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Email</label>
                            <input type="email" name="email" value="<?php echo e(old('email', $hotelInfo->email ?? '')); ?>" required
                                   class="w-full p-3 border border-[#A48374] rounded-lg focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Phone</label>
                            <input type="text" name="phone" value="<?php echo e(old('phone', $hotelInfo->phone ?? '')); ?>" required
                                   class="w-full p-3 border border-[#A48374] rounded-lg focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Address</label>
                            <textarea name="address" rows="2" required
                                      class="w-full p-3 border border-[#A48374] rounded-lg focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200"><?php echo e(old('address', $hotelInfo->address ?? '')); ?></textarea>
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Description</label>
                            <textarea name="description" rows="4" required
                                      class="w-full p-3 border border-[#A48374] rounded-lg focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200"><?php echo e(old('description', $hotelInfo->description ?? '')); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="mt-8">
                        <button type="submit" class="px-6 py-3 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] hover:from-[#A48374]/90 hover:to-[#CBAD8D]/90 text-[#3A2D28] rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-md">
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\proyek_akhir_wfd\resources\views/admin/hotel-info.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Book Your Stay'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-12 px-4 max-w-7xl mx-auto">
    <div class="mb-8">
        <h1 class="text-3xl font-serif font-bold text-[#3A2D28] mb-2">Book Your Stay</h1>
        <p class="text-[#A48374]"><?php echo e($roomType->name); ?></p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div class="lg:col-span-2">
            <div class="bg-[#EBE3DB] p-6 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl">
                <h2 class="text-xl font-semibold text-[#3A2D28] mb-4">Booking Details</h2>
                
                <form action="<?php echo e(route('booking.store')); ?>" method="POST" id="bookingForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="room_id" value="<?php echo e($availableRooms->first()->id); ?>">
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                        <div>
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Check-in Date</label>
                            <input type="date" name="check_in" id="check_in" 
                                   value="<?php echo e($check_in ?? now()->format('Y-m-d')); ?>"
                                   min="<?php echo e(now()->format('Y-m-d')); ?>"
                                   class="w-full p-3 border border-[#A48374] rounded-lg focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Check-out Date</label>
                            <input type="date" name="check_out" id="check_out"
                                   value="<?php echo e($check_out ?? now()->addDay()->format('Y-m-d')); ?>"
                                   min="<?php echo e(now()->addDay()->format('Y-m-d')); ?>"
                                   class="w-full p-3 border border-[#A48374] rounded-lg focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-[#3A2D28] mb-2">Duration</label>
                            <div class="p-3 border border-[#A48374] rounded-lg bg-[#D1C7BD] text-center" id="durationDisplay">
                                <?php if(isset($nights)): ?>
                                <?php echo e($nights); ?> nights
                                <?php else: ?>
                                1 night
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-[#3A2D28] mb-2">Select Room</label>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $availableRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center p-3 border border-[#A48374] rounded-lg hover:bg-[#D1C7BD] transition-colors duration-200">
                                    <input type="radio" name="room_id" id="room_<?php echo e($room->id); ?>" value="<?php echo e($room->id); ?>" class="h-4 w-4 text-[#A48374] focus:ring-[#CBAD8D]" <?php echo e($loop->first ? 'checked' : ''); ?>>
                                    <label for="room_<?php echo e($room->id); ?>" class="ml-3 block">
                                        <span class="font-medium text-[#3A2D28]">Room <?php echo e($room->room_number); ?></span>
                                        <span class="text-sm text-[#A48374] ml-2">Floor <?php echo e($room->floor); ?></span>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <label for="special_requests" class="block text-sm font-medium text-[#3A2D28] mb-2">Special Requests (Optional)</label>
                        <textarea name="special_requests" id="special_requests" rows="3" class="w-full border border-[#A48374] rounded-lg p-3 focus:ring-2 focus:ring-[#CBAD8D] focus:border-transparent transition-all duration-200" placeholder="Any special requests or notes..."></textarea>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row justify-between items-center border-t border-[#A48374] pt-6 gap-4">
                        <?php if(isset($check_in, $check_out)): ?>
                        <a href="<?php echo e(route('booking.check')); ?>?check_in=<?php echo e($check_in); ?>&check_out=<?php echo e($check_out); ?>" class="text-[#A48374] hover:text-[#3A2D28] font-medium transition-colors duration-200">
                            Back to Available Rooms
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('home')); ?>" class="text-[#A48374] hover:text-[#3A2D28] font-medium transition-colors duration-200">
                            Back to Home
                        </a>
                        <?php endif; ?>
                        <button type="submit" class="px-6 py-3 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] hover:from-[#A48374]/90 hover:to-[#CBAD8D]/90 text-[#3A2D28] rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-md">
                            Confirm Booking
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <div>
            <div class="bg-[#EBE3DB] p-6 rounded-xl shadow-lg sticky top-4 transition-all duration-300 hover:shadow-xl">
                <h2 class="text-xl font-semibold text-[#3A2D28] mb-4">Booking Summary</h2>
                
                <div class="mb-6">
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-[#A48374]">Room Type</span>
                        <span class="font-medium text-[#3A2D28]"><?php echo e($roomType->name); ?></span>
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-[#A48374]">Price per night</span>
                        <span class="text-[#3A2D28]">Rp <?php echo e(number_format($roomType->price_per_night, 0, ',', '.')); ?></span>
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-[#A48374]">Nights</span>
                        <span id="summaryNights" class="text-[#3A2D28]">
                            <?php if(isset($nights)): ?>
                            <?php echo e($nights); ?>

                            <?php else: ?>
                            1
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="border-t border-[#A48374] my-3"></div>
                    <div class="flex justify-between items-center font-semibold text-lg text-[#3A2D28]">
                        <span>Total</span>
                        <span id="summaryTotal">
                            Rp <?php if(isset($total)): ?>
                            <?php echo e(number_format($total, 0, ',', '.')); ?>

                            <?php else: ?>
                            <?php echo e(number_format($roomType->price_per_night, 0, ',', '.')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                </div>
                
                <div class="border-t border-[#A48374] pt-6">
                    <h3 class="font-semibold text-[#3A2D28] mb-2">Cancellation Policy</h3>
                    <p class="text-sm text-[#A48374]">
                        Free cancellation up to 24 hours before check-in. No refund for late cancellations or no-shows.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkInInput = document.getElementById('check_in');
    const checkOutInput = document.getElementById('check_out');
    const durationDisplay = document.getElementById('durationDisplay');
    const summaryNights = document.getElementById('summaryNights');
    const summaryTotal = document.getElementById('summaryTotal');
    const pricePerNight = <?php echo e($roomType->price_per_night); ?>;

    function calculateDuration() {
        const checkInDate = new Date(checkInInput.value);
        const checkOutDate = new Date(checkOutInput.value);
        
        // Ensure check-out is at least 1 day after check-in
        if (checkOutDate <= checkInDate) {
            const nextDay = new Date(checkInDate);
            nextDay.setDate(nextDay.getDate() + 1);
            checkOutInput.valueAsDate = nextDay;
            checkOutDate = nextDay;
        }

        const timeDiff = checkOutDate - checkInDate;
        const nights = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
        
        durationDisplay.textContent = nights + (nights === 1 ? ' night' : ' nights');
        summaryNights.textContent = nights;
        summaryTotal.textContent = 'Rp ' + (pricePerNight * nights).toLocaleString('id-ID');
    }

    checkInInput.addEventListener('change', function() {
        const checkInDate = new Date(this.value);
        const minCheckOutDate = new Date(checkInDate);
        minCheckOutDate.setDate(minCheckOutDate.getDate() + 1);
        
        checkOutInput.min = minCheckOutDate.toISOString().split('T')[0];
        
        if (new Date(checkOutInput.value) <= checkInDate) {
            checkOutInput.valueAsDate = minCheckOutDate;
        }
        
        calculateDuration();
    });

    checkOutInput.addEventListener('change', calculateDuration);

    // Initial calculation
    calculateDuration();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon_new\www\pa_wfd_ken\project_uas\resources\views/booking/create.blade.php ENDPATH**/ ?>
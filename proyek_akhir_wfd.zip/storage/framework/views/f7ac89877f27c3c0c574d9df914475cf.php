

<?php $__env->startSection('title', 'Room Availability'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-12 px-4 max-w-7xl mx-auto">
    <div class="mb-8">
        <h1 class="text-3xl font-serif font-bold text-[#3A2D28] mb-2">Available Rooms</h1>
        <?php if(isset($search)): ?>
        <p class="text-[#A48374]">
            <?php echo e(\Carbon\Carbon::parse($search['check_in'])->format('M d, Y')); ?> to 
            <?php echo e(\Carbon\Carbon::parse($search['check_out'])->format('M d, Y')); ?>

        </p>
        <?php endif; ?>
    </div>

    <?php if($availableRoomTypes->isEmpty()): ?>
        <div class="bg-[#EBE3DB] p-8 rounded-xl shadow-lg text-center transition-all duration-300 hover:shadow-xl">
            <div class="w-16 h-16 bg-[#D1C7BD] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-[#A48374]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <h3 class="text-xl font-semibold text-[#3A2D28] mb-4">No rooms available for your selected dates</h3>
            <p class="text-[#A48374] mb-6">Please try adjusting your dates.</p>
            <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] hover:from-[#A48374]/90 hover:to-[#CBAD8D]/90 text-[#3A2D28] rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-md">
                Search Again
            </a>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 gap-8">
            <?php $__currentLoopData = $availableRoomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-[#EBE3DB] rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:transform hover:-translate-y-1">
                    <div class="md:flex">
                        <div class="md:w-1/3">
                            <?php if($roomType->name === 'Deluxe Room'): ?>
                                <img src="<?php echo e(asset('storage/images/deluxe.jpg')); ?>" alt="Deluxe Room" class="w-full h-64 md:h-full object-cover transition-transform duration-500 hover:scale-105">
                            <?php elseif($roomType->name === 'Premier Suite'): ?>
                                <img src="<?php echo e(asset('storage/images/premiere.jpg')); ?>" alt="Premier Suite" class="w-full h-64 md:h-full object-cover transition-transform duration-500 hover:scale-105">
                            <?php elseif($roomType->name === 'Executive Lounge'): ?>
                                <img src="<?php echo e(asset('storage/images/executive.jpg')); ?>" alt="Executive Lounge" class="w-full h-64 md:h-full object-cover transition-transform duration-500 hover:scale-105">
                            <?php else: ?>
                                <img src="<?php echo e($roomType->image_url); ?>" alt="<?php echo e($roomType->name); ?>" class="w-full h-64 md:h-full object-cover transition-transform duration-500 hover:scale-105">
                            <?php endif; ?>
                        </div>
                        <div class="p-6 md:w-2/3">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h2 class="text-2xl font-serif font-bold text-[#3A2D28] mb-2"><?php echo e($roomType->name); ?></h2>
                                    <div class="flex items-center mb-2">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <svg class="w-4 h-4 text-[#CBAD8D]" fill="currentColor" viewBox="0 0 20 20">
                                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                            </svg>
                                        <?php endfor; ?>
                                        <span class="text-xs text-[#A48374] ml-1">(24 reviews)</span>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <p class="text-lg font-semibold text-[#3A2D28]">Rp <?php echo e(number_format($roomType->price_per_night, 0, ',', '.')); ?></p>
                                    <p class="text-sm text-[#A48374]">per night</p>
                                </div>
                            </div>
                            
                            <p class="text-[#3A2D28] mb-4"><?php echo e($roomType->description); ?></p>
                            
                            <div class="flex justify-end">
                                <?php if(isset($search)): ?>
                                <a href="<?php echo e(route('booking.create', $roomType)); ?>?check_in=<?php echo e($search['check_in']); ?>&check_out=<?php echo e($search['check_out']); ?>" class="px-6 py-2 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] hover:from-[#A48374]/90 hover:to-[#CBAD8D]/90 text-[#3A2D28] rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-md">
                                    Book Now
                                </a>
                                <?php else: ?>
                                <a href="<?php echo e(route('booking.create', $roomType)); ?>" class="px-6 py-2 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] hover:from-[#A48374]/90 hover:to-[#CBAD8D]/90 text-[#3A2D28] rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-md">
                                    Book Now
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon_new\www\pa_wfd_ken\project_uas\resources\views/booking/availability.blade.php ENDPATH**/ ?>
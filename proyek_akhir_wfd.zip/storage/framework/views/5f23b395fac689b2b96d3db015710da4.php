

<?php $__env->startSection('title', 'Create Room Type'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex">
    <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <div class="flex-1 p-8">
        <h1 class="text-3xl font-bold mb-8">Create New Room Type</h1>
        
        <div class="bg-white p-6 rounded-lg shadow">
            <form action="<?php echo e(route('admin.rooms.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" required
                               class="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Price per night</label>
                        <input type="number" name="price_per_night" value="<?php echo e(old('price_per_night')); ?>" required min="0"
                               class="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <!-- <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Capacity</label>
                        <input type="number" name="capacity" value="<?php echo e(old('capacity')); ?>" required min="1"
                               class="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500">
                    </div> -->
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Facilities</label>
                        <input type="text" name="facilities" value="<?php echo e(old('facilities')); ?>" required
                               class="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                        <textarea name="description" rows="3" required
                                  class="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"><?php echo e(old('description')); ?></textarea>
                    </div>
                    
                    <!-- <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Image</label>
                        <input type="file" name="image" accept="image/*" required
                               class="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500">
                        <p class="text-xs text-gray-500 mt-1">Upload image (jpg, png, jpeg) max 2MB</p>
                    </div> -->
                </div>
                
                <div class="mt-6 flex justify-end">
                    <a href="<?php echo e(route('admin.rooms.index')); ?>" class="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded mr-2">
                        Cancel
                    </a>
                    <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded">
                        Create Room Type
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon_new\www\pa_wfd_ken\project_uas\resources\views/admin/rooms/create.blade.php ENDPATH**/ ?>
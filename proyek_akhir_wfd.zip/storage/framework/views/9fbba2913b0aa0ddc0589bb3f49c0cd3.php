

<?php $__env->startSection('title', 'My Bookings'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-12 px-4 max-w-7xl mx-auto">
    <div class="mb-8">
        <h1 class="text-3xl font-serif font-bold text-[#3A2D28] mb-2">My Bookings</h1>
        <p class="text-[#A48374]">View and manage your upcoming and past bookings</p>
    </div>

    <?php if($bookings->isEmpty()): ?>
        <div class="bg-[#EBE3DB] p-8 rounded-xl shadow-lg text-center transition-all duration-300 hover:shadow-xl">
            <div class="w-16 h-16 bg-[#D1C7BD] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-[#A48374]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <h3 class="text-xl font-semibold text-[#3A2D28] mb-4">You don't have any bookings yet</h3>
            <p class="text-[#A48374] mb-6">Start by searching for available rooms for your next stay.</p>
            <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] hover:from-[#A48374]/90 hover:to-[#CBAD8D]/90 text-[#3A2D28] rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-md">
                Book a Room
            </a>
        </div>
    <?php else: ?>
        <div class="bg-[#EBE3DB] rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl">
            <div class="divide-y divide-[#D1C7BD]">
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-6 hover:bg-[#D1C7BD] transition-colors duration-200">
                        <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                            <div class="mb-4 md:mb-0">
                                <div class="flex items-center">
                                    <h2 class="text-lg font-semibold text-[#3A2D28]"><?php echo e($booking->room->roomType->name); ?></h2>
                                    <span class="ml-2 px-3 py-1 text-xs rounded-full 
                                        <?php echo e($booking->status === 'confirmed' ? 'bg-[#CBAD8D] text-[#3A2D28] animate-pulse' : ''); ?>

                                        <?php echo e($booking->status === 'completed' ? 'bg-[#D1C7BD] text-[#3A2D28]' : ''); ?>

                                        <?php echo e($booking->status === 'cancelled' ? 'bg-[#A48374] text-[#F1EDE6]' : ''); ?>">
                                        <?php echo e(ucfirst($booking->status)); ?>

                                    </span>
                                </div>
                                <p class="text-[#A48374] text-sm mt-1">
                                    <?php echo e($booking->check_in->format('M d, Y')); ?> - <?php echo e($booking->check_out->format('M d, Y')); ?> (<?php echo e($booking->nights); ?> nights)
                                </p>
                                <p class="text-[#A48374] text-sm">Booking #<?php echo e($booking->booking_number); ?></p>
                            </div>
                            
                            <div class="flex flex-col sm:flex-row gap-2">
                                <a href="<?php echo e(route('booking.confirmation', $booking)); ?>" class="px-4 py-2 bg-[#EBE3DB] hover:bg-[#D1C7BD] text-[#A48374] border border-[#A48374] rounded-lg text-sm font-medium transition-all duration-200 transform hover:scale-105">
                                    View Details
                                </a>
                                
                                <?php if($booking->status === 'completed' && !$booking->review): ?>
                                    <a href="<?php echo e(route('review.create', $booking)); ?>" class="px-4 py-2 bg-gradient-to-r from-[#A48374] to-[#CBAD8D] hover:from-[#A48374]/90 hover:to-[#CBAD8D]/90 text-[#3A2D28] rounded-lg text-sm font-medium transition-all duration-200 transform hover:scale-105 shadow-md">
                                        Write Review
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon_new\www\pa_wfd_ken\project_uas\resources\views/booking/my-bookings.blade.php ENDPATH**/ ?>